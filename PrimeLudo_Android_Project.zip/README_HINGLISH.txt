PRIME LUDO - ANDROID PROJECT

ZIP MEIN KYA HAI
- Android Studio / GitHub Actions build-ready Android project
- assets/index.html: game UI + Ludo game logic
- .github/workflows/android-apk.yml: APK build workflow

GITHUB ACTIONS SE APK KAISE BANAYE (MOBILE SE)
1. GitHub par naya repository banao: PrimeLudo
2. Repository ke root mein PrimeLudo_Android_Project.zip upload karo.
3. GitHub mein Add file > Create new file kholo aur filename likho:
   .github/workflows/android-apk.yml
4. Download ki hui android-apk.yml file ka poora content paste karke commit karo.
   (Agar ZIP extract karke saari project files upload karte ho, to workflow ZIP ke andar bhi included hai.)
5. Repository ke Actions tab kholo.
6. "Prime Ludo APK Build" workflow select karo aur Run workflow dabao.
7. Green tick aane ke baad workflow run > Artifacts > Prime-Ludo-debug-APK download karo.
8. Artifact ZIP extract karke app-debug.apk install karo.

GAME MODES
- Offline 4 Players: ek hi phone par 4 players.
- Offline vs Computer: tum + 3 CPU players.
- Online: Host room banao, room code share karo; friends same code se join karenge.
- Online multiplayer PeerJS public signaling cloud use karta hai. Internet aur PeerJS CDN access zaroori hai.
  Public/free signaling availability guaranteed nahi hoti. Production launch ke liye apna signaling/server setup recommended hai.

IMPORTANT
- Ye first full playable foundation hai, commercial-grade production build nahi.
- Online multiplayer ke liye host ko game ke dauran online rehna hoga.
- Debug APK testing ke liye hai. Play Store release ke liye signed release build aur privacy policy chahiye.
